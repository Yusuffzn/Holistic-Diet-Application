package com.example.holisticapplication;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class SignUpGoal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up_goal);


        //Listener buttonSignUp
        android.widget.Button buttonSubmit = (android.widget.Button) findViewById(R.id.buttonLetsGo);
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signUpGoalSubmit();
            }
        });

        //remove error handlng
        hideErrorHandling();

        //measurement used
        measurmentUsed();

    }// onCreate

    //signUpGoalSubmit
    public void signUpGoalSubmit(){
        DBadapter db = new DBadapter(this);
        db.open();
        //error
        android.widget.TextView textViewErrorMessage = (android.widget.TextView) findViewById(R.id.textViewErrorMessage);
        String errormessage = "";

        //get target weight
        android.widget.EditText editTextTargetWeight = (android.widget.EditText) findViewById(R.id.editTextTargetWeight);
        String stringTargetWeight = editTextTargetWeight.getText().toString();
        double doubleTargetWeight = 0;
        try {
            doubleTargetWeight = Double.parseDouble(stringTargetWeight);
        }
        catch (NumberFormatException nfe) {
            errormessage = "Target weight has to be a number";
        }

        //spinner
        android.widget.Spinner spinnerIWantTo = (android.widget.Spinner) findViewById(R.id.spinnerIWantTo);
        int intIWantTo = spinnerIWantTo.getSelectedItemPosition();

        android.widget.Spinner spinnerWeeklyGoal = (android.widget.Spinner) findViewById(R.id.spinnerWeeklyGoal);
        String stringWeeklyGoal = spinnerWeeklyGoal.getSelectedItem().toString();

        //update fields
        if(errormessage.isEmpty()){
            //update database


            long goalID = 1;

            double doubleTargetWeightSQL = db.quoteSmart(doubleTargetWeight);
            db.update("goal", "_id", goalID, "goal_target_weight", doubleTargetWeightSQL);

            int intIWantToSQL = db.quoteSmart(intIWantTo);
            db.update ("goal", "_id", goalID, "goal_i_want_to", intIWantToSQL);

            String stringWeeklyGoalSQL = db.quoteSmart(stringWeeklyGoal);
            db.update ("goal", "_id", goalID, "goal_weekly_goal", stringWeeklyGoalSQL);

        }

        /* Calculate energy */
        if(errormessage.isEmpty()){

            // Get row number one from users
            long rowID = 1;
            String fields[] = new String[] {
                    "_id",
                    "user_dob",
                    "user_gender",
                    "user_height",
                    "user_activity_level"
            };
            Cursor c = db.selectPrimaryKey("users", "_id", rowID, fields);
            String stringUserDob = c.getString(1);
            String stringUserGender  = c.getString(2);
            String stringUserHeight = c.getString(3);
            String stringUserActivityLevel = c.getString(4);

            // Get weight actvity level
            rowID = 1;
            String fieldsGoal[] = new String[] {
                    "_id",
                    "goal_current_weight",
                    "goal_activity_level"
            };
            Cursor cGoal = db.select("goal", fieldsGoal, "_id", rowID);
            String stringUserCurrentWeight = cGoal.getString(1);

            // Get weight
            double doubleUserCurrentWeight = 0;
            try{
                doubleUserCurrentWeight = Double.parseDouble(stringUserCurrentWeight);
            }
            catch(NumberFormatException nfe) {
                System.out.println("Could not parse " + nfe);
            }

            // Get Age
            String[] items1 = stringUserDob.split("-");
            String stringDay = items1[0];
            String stringMonth = items1[1];
            String stringYear = items1[2];


            int intDay = 0;
            try {
                intDay = Integer.parseInt(stringDay);
            }
            catch(NumberFormatException nfe) {
                System.out.println("Could not parse " + nfe);
            }

            int intMonth = 0;
            try {
                intMonth = Integer.parseInt(stringMonth);
            }
            catch(NumberFormatException nfe) {
                System.out.println("Could not parse " + nfe);
            }

            int intYear = 0;
            try {
                intYear = Integer.parseInt(stringYear);
            }
            catch(NumberFormatException nfe) {
                System.out.println("Could not parse " + nfe);
            }

            String stringUserAge = getAge(intDay, intMonth, intYear);

            int intUserAge = 0;
            try {
                intUserAge = Integer.parseInt(stringUserAge);
            }
            catch(NumberFormatException nfe) {
                System.out.println("Could not parse " + nfe);
            }

            // Height
            double doubleUserHeight = 0;
            try {
                doubleUserHeight = Double.parseDouble(stringUserHeight);
            }
            catch(NumberFormatException nfe) {
                System.out.println("Could not parse " + nfe);
            }
            //Toast.makeText(this, "DOB=" + stringUserDob + "\nAge=" + stringUserAge + "\nGender=" + stringUserGender + "\nHeight=" + stringUserHeight + "\nActivity level=" + stringUserActivityLevel, Toast.LENGTH_LONG).show();

            // Start calculation
            double bmr = 0;
            if(stringUserGender.startsWith("m")){
                // Male
                // BMR = 66.5 + (13.75 x kg body weight) + (5.003 x height in cm) - (6.755 x age)
                bmr = 66.5+(13.75*doubleTargetWeight)+(5.003*doubleUserHeight)-(6.755*intUserAge);
                //bmr = Math.round(bmr);
                //Toast.makeText(this, "BMR formula: 66.5+(13.75*" + doubleTargetWeight + ")+(5.003*" + doubleUserHeight + ")-(6.755*" + intUserAge, Toast.LENGTH_LONG).show();

            } // if(stringUserGender.startsWith("m")){
            else{
                // Female
                // BMR = 55.1 + (9.563 x kg body weight) + (1.850 x height in cm) - (4.676 x age)
                bmr = 655+(9.563*doubleTargetWeight)+(1.850*doubleUserHeight)-(4.676*intUserAge);
                //bmr = Math.round(bmr);
            }
            bmr = Math.round(bmr);
            long goalID = 1;
            double energyBmrSQL = db.quoteSmart(bmr);
            db.update("goal", "_id", goalID, "goal_energy_bmr", energyBmrSQL);
            //Toast.makeText(this, "BMR before activity: " + bmr, Toast.LENGTH_LONG).show();

            // Calcualte proteins
            // 20-25 % protein
            // 40-50 % carbs
            // 25-35 % fat
            double proteinsBMR = Math.round(bmr*25/100);
            double carbsBMR = Math.round(bmr*50/100);
            double fatBMR = Math.round(bmr*25/100);

            double proteinsBMRSQL = db.quoteSmart(proteinsBMR);
            double carbsBMRSQL = db.quoteSmart(carbsBMR);
            double fatBMRSQL = db.quoteSmart(fatBMR);
            db.update("goal", "_id", goalID, "goal_proteins_bmr", proteinsBMRSQL);
            db.update("goal", "_id", goalID, "goal_carbs_bmr", carbsBMRSQL);
            db.update("goal", "_id", goalID, "goal_fat_bmr", fatBMRSQL);

            //2. diet
            // Loose or gain weight?
            double doubleWeeklyGoal = 0;
            try {
                doubleWeeklyGoal = Double.parseDouble(stringWeeklyGoal);
            }
            catch(NumberFormatException nfe) {
                System.out.println("Could not parse " + nfe);
            }

            // 1 kg fat = 7700 kcal
            double kcal = 0;
            double energyDiet = 0;
            kcal = 7700*doubleWeeklyGoal;
            if(intIWantTo == 0){
                // Loose weight
                energyDiet = Math.round(bmr - (kcal/7));

            }
            else{
                // Gain weight
                energyDiet = Math.round(bmr + (kcal/7));
            }

            // Update database
            double energyDietSQL = db.quoteSmart(energyDiet);
            db.update("goal", "_id", goalID, "goal_energy_diet", energyDiet);

            // Calcualte proteins
            // 20-25 % protein
            // 40-50 % carbs
            // 25-35 % fat
            double proteinsDiet = Math.round(energyDiet*25/100);
            double carbsDiet = Math.round(energyDiet*50/100);
            double fatDiet = Math.round(energyDiet*25/100);

            double proteinsDietSQL = db.quoteSmart(proteinsDiet);
            double carbsDietSQL = db.quoteSmart(carbsDiet);
            double fatDietSQL = db.quoteSmart(fatDiet);
            db.update("goal", "_id", goalID, "goal_proteins_diet", proteinsBMRSQL);
            db.update("goal", "_id", goalID, "goal_carbs_diet", carbsBMRSQL);
            db.update("goal", "_id", goalID, "goal_fat_diet", fatBMRSQL);


            //3. with activity
            // Taking in to account activity
            double energyWithActivity = 0;
            if(stringUserActivityLevel.equals("0")) {
                energyWithActivity = bmr * 1.2;
            }
            else if(stringUserActivityLevel.equals("1")) {
                energyWithActivity = bmr * 1.375; // slightly_active
            }
            else if(stringUserActivityLevel.equals("2")) {
                energyWithActivity = bmr*1.55; // moderately_active
            }
            else if(stringUserActivityLevel.equals("3")) {
                energyWithActivity = bmr*1.725; // active_lifestyle
            }
            else if(stringUserActivityLevel.equals("3")) {
                energyWithActivity = bmr * 1.9; // very_active
            }
            energyWithActivity = Math.round(energyWithActivity);
            double energyWithActivitySQL = db.quoteSmart(energyWithActivity);
            db.update("goal", "_id", goalID, "goal_energy_with_activity", energyWithActivitySQL);
            //Toast.makeText(this, "BMR after activity: " + bmr, Toast.LENGTH_LONG).show();

            // Calcualte proteins
            // 20-25 % protein
            // 40-50 % carbs
            // 25-35 % fat
            double proteinsWithActivity = Math.round(energyWithActivity*25/100);
            double carbsWithActivity = Math.round(energyWithActivity*50/100);
            double fatWithActivity = Math.round(energyWithActivity*25/100);

            double proteinsWithActivitySQL = db.quoteSmart(proteinsWithActivity);
            double carbsWithActivitySQL = db.quoteSmart(carbsWithActivity);
            double fatWithActivitySQL = db.quoteSmart(fatWithActivity);
            db.update("goal", "_id", goalID, "goal_proteins_with_activity", proteinsWithActivitySQL);
            db.update("goal", "_id", goalID, "goal_carbs_with_activity", carbsWithActivitySQL);
            db.update("goal", "_id", goalID, "goal_fat_with_activity", fatWithActivitySQL);


            //4. w activity n diet
            // 1 kg fat = 7700 kcal
            kcal = 0;
            double energyWithActivityAndDiet = 0;
            kcal = 7700*doubleWeeklyGoal;
            if(intIWantTo == 0){
                // Loose weight
                energyWithActivityAndDiet = Math.round(bmr - (kcal/7));

            }
            else{
                // Gain weight
                energyWithActivityAndDiet = Math.round(bmr + (kcal/7));
            }

            // Update database
            double energyWithActivityAndDietSQL = db.quoteSmart(energyWithActivityAndDiet);
            db.update("goal", "_id", goalID, "goal_energy_with_activity_and_diet", energyWithActivityAndDietSQL);


            // Calcualte proteins
            // 20-25 % protein
            // 40-50 % carbs
            // 25-35 % fat
            double proteins = Math.round(energyWithActivityAndDiet*25/100);
            double carbs = Math.round(energyWithActivityAndDiet*50/100);
            double fat = Math.round(energyWithActivityAndDiet*25/100);

            double proteinsSQL = db.quoteSmart(proteins);
            double carbsSQL = db.quoteSmart(carbs);
            double fatSQL = db.quoteSmart(fat);
            db.update("goal", "_id", goalID, "goal_proteins_with_activity_and_diet", proteinsSQL);
            db.update("goal", "_id", goalID, "goal_carbs_with_activity_and_diet", carbsSQL);
            db.update("goal", "_id", goalID, "goal_fat_with_activity_and_diet", fatSQL);

        } //  /* Calculate energy */



        //error handling
        if(!(errormessage.isEmpty())){
            textViewErrorMessage.setText(errormessage);
            textViewErrorMessage.setVisibility(View.VISIBLE);
        }
        db.close();

        if(errormessage.isEmpty()){
            Intent i = new Intent(SignUpGoal.this, MainActivity.class);
            startActivity(i);
        }
    }//signUpGoalSubmit

    //hide error handling
    public void hideErrorHandling(){
        android.widget.TextView textViewErrorMessage = (android.widget.TextView) findViewById(R.id.textViewErrorMessage);
        textViewErrorMessage.setVisibility(View.GONE);
    }

    //measurmentused
    public void measurmentUsed(){
        //database
        DBadapter db = new DBadapter(this);
        db.open();

        //get row number one from user
        long rowID = 1;
        String fields[] = new String[] {
                "_id",
                "user_measurment"
        };

        Cursor c = db.selectPrimaryKey ("users", "_id", rowID, fields);
        String measurment;
        measurment = c.getString (1);

        // Metric or imperial?
        if (measurment.startsWith("m")){
            // Metric
        }
        else{
            // Imperial

            // Kg to punds
            android.widget.TextView textViewTargetMeasurmentType = (android.widget.TextView) findViewById(R.id.textViewTargetMeasurmentType);
            textViewTargetMeasurmentType.setText("lbs");

            //kg each week to pound each week
            android.widget.TextView textViewKgEachWeek = (android.widget.TextView) findViewById(R.id.textViewKgEachWeek);
            textViewKgEachWeek.setText("lbs each week");

        }

        //close data
        db.close();

    }
    /* getAge -------------------------------------------------------------- */
    private String getAge(int year, int month, int day){
        Calendar dob = Calendar.getInstance();
        Calendar today = Calendar.getInstance();


        dob.set(day, month, year);

        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)){
            age--;
        }

        Integer ageInt = new Integer(age);
        String ageS = ageInt.toString();

        return ageS;
    }
}
