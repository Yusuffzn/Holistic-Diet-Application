package com.example.holisticapplication;

import android.content.Intent;
import android.graphics.Color;
import android.icu.number.Scale;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.view.View;
import android.view.animation.ScaleAnimation;
import android.widget.AdapterView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;


public class SignUp extends AppCompatActivity {

    private String[] arraySpinnerDOBDay = new String[31];
    private String[] arraySpinnerDOBYear = new String[100];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);

        /* Fill numbers for date of birth days */
        int human_counter = 0;
        for (int x = 0; x < 31; x++) {
            human_counter = x + 1;
            this.arraySpinnerDOBDay[x] = "" + human_counter;
        }
        android.widget.Spinner spinnerDOBDay = (android.widget.Spinner) findViewById(R.id.spinnerDOBDay);
        android.widget.ArrayAdapter<String> adapter = new android.widget.ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, arraySpinnerDOBDay);
        spinnerDOBDay.setAdapter(adapter);

        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(calendar.YEAR);
        int end = year - 100;
        int index = 0;
        for (int x = year; x > end; x--) {
            this.arraySpinnerDOBYear[index] = "" + x;

            index++;
        }

        android.widget.Spinner spinnerDOBYear = (android.widget.Spinner) findViewById(R.id.spinnerDOBYear);
        android.widget.ArrayAdapter<String> adapterYear = new android.widget.ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, arraySpinnerDOBYear);
        spinnerDOBYear.setAdapter(adapterYear);

        //hide error message
        android.widget.TextView textViewErrorMessage = (android.widget.TextView) findViewById(R.id.textViewErrorMessage);
        textViewErrorMessage.setVisibility(View.GONE);

        //hide feet inches
        android.widget.EditText editTextHeightInches = (android.widget.EditText) findViewById(R.id.editTextHeightInches);
        editTextHeightInches.setVisibility(View.GONE);

        //Listener measurement spinner
        android.widget.Spinner spinnermeasurments = (android.widget.Spinner) findViewById(R.id.spinnermeasurments);
        spinnermeasurments.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                measurmentChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                measurmentChanged();
            }

        });


        //Listener buttonSignUp
        android.widget.Button buttonSignUp = (android.widget.Button) findViewById(R.id.buttonSignUp);
        buttonSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signUpSubmit();
            }
        });

    }//protected void onCreate

    public void measurmentChanged() {
        //measurement
        android.widget.Spinner spinnermeasurments = (android.widget.Spinner) findViewById(R.id.spinnermeasurments);
        String stringMeasurments = spinnermeasurments.getSelectedItem().toString();

        android.widget.EditText editTextHeightCm = (android.widget.EditText) findViewById(R.id.editTextHeightCm);
        android.widget.EditText editTextHeightInches = (android.widget.EditText) findViewById(R.id.editTextHeightInches);
        String stringHeightCm = editTextHeightCm.getText().toString();
        String stringHeightInches = editTextHeightInches.getText().toString();

        double heightCm = 0;
        double heightFeet = 0;
        double heightInches = 0;
        android.widget.TextView textViewCm = (android.widget.TextView) findViewById(R.id.textViewCm);
        android.widget.TextView textViewkg = (android.widget.TextView) findViewById(R.id.textViewKg);

        if (stringMeasurments.startsWith("I")) {
            //imperial
            editTextHeightInches.setVisibility(View.VISIBLE);
            textViewCm.setText("feet and inches");
            textViewkg.setText("pound");

            //find feet
            try {
                heightCm = Double.parseDouble(stringHeightCm);
            }
            catch (NumberFormatException nfe) {

            }
            if (heightCm != 0){
                heightFeet = (heightCm * 0.3937008)/12;
                int intHeightFeet = (int) heightFeet;
                editTextHeightCm.setText("" + intHeightFeet);
            }

        } else {
            //metric
            editTextHeightInches.setVisibility(View.GONE);
            textViewCm.setText("cm");
            textViewkg.setText("kg");

            //change inches to cm
            //convert Feet
            try {
                heightFeet = Double.parseDouble(stringHeightCm);
            }
            catch (NumberFormatException nfe) {

            }
            //convert Inches
            try {
                heightInches = Double.parseDouble(stringHeightInches);
            }
            catch (NumberFormatException nfe){

            }

            if (heightFeet != 0 && heightInches != 0) {
                heightCm = ((heightFeet * 12) + heightInches) * 2.54;
                heightCm = Math.round(heightCm);
                editTextHeightCm.setText("" + heightCm);
            }
        }

        //weight
        android.widget.EditText editTextWeight = (android.widget.EditText) findViewById (R.id.editTextWeight);
        String stringWeight = editTextWeight.getText().toString();
        double doubleWeight = 0;

        try {
            doubleWeight = Double.parseDouble(stringWeight);
        }
        catch (NumberFormatException nfe){
        }

        if (doubleWeight != 0) {
            if (stringMeasurments.startsWith("I")) {

                //kg to pound
                doubleWeight = Math.round(doubleWeight / 0.45359237);
            } else {

                //pound to kg
                doubleWeight = Math.round(doubleWeight * 0.45359237);
            }
            editTextWeight.setText("" + doubleWeight);
        }
    }

    //sign up Submit
    public void signUpSubmit(){
        //error
        android.widget.TextView textViewErrorMessage = (android.widget.TextView) findViewById(R.id.textViewErrorMessage);
        String errorMessage = "";
        // Email
        android.widget.TextView textViewEmail = (android.widget.TextView) findViewById (R.id.textViewEmail);

        android.widget.TextView editTextEmail = (android.widget.EditText) findViewById (R.id.editTextEmail);
        String stringEmail = editTextEmail.getText().toString ();
        if (stringEmail.isEmpty() || stringEmail.startsWith(" ")){
            errorMessage = "Please fill in an e-mail address.";
        }

        //date of birthday
        android.widget.Spinner spinnerDOBDay = (android.widget.Spinner) findViewById(R.id.spinnerDOBDay);
        String stringDOBDay = spinnerDOBDay.getSelectedItem().toString();
        int intDOBDay = 0;
        try {
            intDOBDay = Integer.parseInt(stringDOBDay);
            if (intDOBDay < 10){
                stringDOBDay = "0" + stringDOBDay;
            }
        }
        catch (NumberFormatException nfe){
            System.out.println("Could not parse " + nfe);
            errorMessage = "Please select a day for your birthday.";
        }
        //date of Month
        android.widget.Spinner spinnerDOBMonth = (android.widget.Spinner) findViewById(R.id.spinnerDOBMonth);
        String stringDOBMonth = spinnerDOBMonth.getSelectedItem().toString();
        if (stringDOBMonth.startsWith("Jan")){
            stringDOBMonth = "01";
        }
        else if (stringDOBMonth.startsWith("Feb")){
            stringDOBMonth = "02";
        }
        else if (stringDOBMonth.startsWith("Mar")){
            stringDOBMonth = "03";
        }
        else if (stringDOBMonth.startsWith("Apr")){
            stringDOBMonth = "04";
        }
        else if (stringDOBMonth.startsWith("May")){
            stringDOBMonth = "05";
        }
        else if (stringDOBMonth.startsWith("Jun")){
            stringDOBMonth = "06";
        }
        else if (stringDOBMonth.startsWith("Jul")){
            stringDOBMonth = "07";
        }
        else if (stringDOBMonth.startsWith("Aug")){
            stringDOBMonth = "08";
        }
        else if (stringDOBMonth.startsWith("Sep")){
            stringDOBMonth = "09";
        }else if (stringDOBMonth.startsWith("Oct")){
            stringDOBMonth = "10";
        }
        else if (stringDOBMonth.startsWith("Nov")){
            stringDOBMonth = "11";
        }
        else if (stringDOBMonth.startsWith("Dec")){
            stringDOBMonth = "12";
        }

        //date of Year
        android.widget.Spinner spinnerDOBYear = (android.widget.Spinner) findViewById(R.id.spinnerDOBYear);
        String stringDOBYear = spinnerDOBYear.getSelectedItem().toString();
        int intDOBYear = 0;
        try {
            intDOBYear = Integer.parseInt(stringDOBYear);
        }
        catch (NumberFormatException nfe){
            System.out.println("Could not parse " + nfe);
            errorMessage = "Please select a day for your birthday.";}

        String dateOfBirth = stringDOBDay + "-" + stringDOBMonth + "-" + stringDOBYear;
        Toast.makeText(this,dateOfBirth,Toast.LENGTH_SHORT).show();

        //GENDER
        android.widget.RadioGroup radioGroupGender = (android.widget.RadioGroup) findViewById(R.id.radioGroupGender);
        int radioButtonID = radioGroupGender.getCheckedRadioButtonId();
        View radioButtonGender = radioGroupGender.findViewById (radioButtonID);
        int position = radioGroupGender.indexOfChild(radioButtonGender);

        String stringGender = "";
        if (position == 1){
            stringGender = "male";
        }
        else {
            stringGender = "female";
        }



        //height
        android.widget.EditText editTextHeightCm = (android.widget.EditText) findViewById (R.id.editTextHeightCm);
        android.widget.EditText editTextHeightInches = (android.widget.EditText) findViewById (R.id.editTextHeightInches);
        String stringHeightCm = editTextHeightCm.getText().toString();
        String stringHeightInches = editTextHeightInches.getText().toString();

        double heightCm = 0;
        double heightFeet = 0;
        double heightInches = 0;
        boolean metric = true;

        android.widget.Spinner spinnermeasurments = (android.widget.Spinner) findViewById(R.id.spinnermeasurments);
        String stringMeasurments = spinnermeasurments.getSelectedItem().toString();

        int intMeasurment = spinnermeasurments.getSelectedItemPosition();
        if (intMeasurment == 0){
            stringMeasurments = "metric";
        }
        else{
            stringMeasurments = "imperial";
            metric = false;

        }

        if (stringMeasurments.startsWith("I")){
            metric = false;
        }
        if (metric == true){
            //convert cm
            try {
                heightCm = Double.parseDouble(stringHeightCm);
                heightCm = Math.round(heightCm);
            }
            catch (NumberFormatException nfe){
                errorMessage = "Height (cm) has to be number.";
            }
        }
        else{
            //convert Feet
            try {
                heightFeet = Double.parseDouble(stringHeightCm);
            }
            catch (NumberFormatException nfe) {
                errorMessage = "Height (feet) has to be number.";
            }
            //convert Inches
            try {
                heightInches = Double.parseDouble(stringHeightInches);
            }
            catch (NumberFormatException nfe){
                errorMessage = "Height (inches) has to be number.";
            }

            heightCm = ((heightFeet * 12) + heightInches) * 2.54;
            heightCm = Math.round(heightCm);
        }

        //weight
        android.widget.EditText editTextWeight = (android.widget.EditText) findViewById (R.id.editTextWeight);
        String stringWeight = editTextWeight.getText().toString();
        double doubleWeight = 0;
        try {
            doubleWeight = Double.parseDouble(stringWeight);
        }
        catch (NumberFormatException nfe){
            errorMessage = "Weight has to be number.";
        }
        if (metric == true){

        }
        else{
            doubleWeight = Math.round(doubleWeight * 0.45359237);
        }

        //activity level
        android.widget.Spinner spinnerActivityLevel = (android.widget.Spinner) findViewById(R.id.spinnerActivityLevel);
        int intActivityLevel = spinnerActivityLevel.getSelectedItemPosition();


        if (errorMessage.isEmpty()){
            textViewErrorMessage.setVisibility(View.GONE);


            //insert into db
            DBadapter db = new DBadapter(this);
            db.open();

            //quote smart
            String stringEmailSQL = db.quoteSmart(stringEmail);
            String dateOfBirthSQL = db.quoteSmart(dateOfBirth);
            String stringGenderSQL = db.quoteSmart(stringGender);
            double heightCmSQL = db.quoteSmart(heightCm);
            int intActivityLevelSQL = db.quoteSmart(intActivityLevel);
            double doubleWeightSQL = db.quoteSmart(doubleWeight);
            String stringMeasurmentsSQL = db.quoteSmart(stringMeasurments);

            String stringInput = "NULL, " + stringEmailSQL + "," + dateOfBirthSQL + "," + stringGenderSQL + "," + heightCmSQL + "," + intActivityLevelSQL + "," + stringMeasurmentsSQL;
            db.insert("users",
                    "_id, user_email, user_dob, user_gender, user_height, user_activity_level, user_measurment",stringInput);

            android.icu.text.DateFormat df1 = new SimpleDateFormat("dd-MM-yyyy"); // Format date
            String goalDate = df1.format(Calendar.getInstance().getTime());

            /*
            Calendar cc = Calendar.getInstance();
            int year = cc.get(Calendar.YEAR);
            int month = cc.get(Calendar.MONTH);
            int mDay = cc.get(Calendar.DAY_OF_MONTH);
            String goalDate = mDay + "-" + month + "-" + year; */

            String goalDateSQL = db.quoteSmart(goalDate);

            stringInput = "NULL, " + doubleWeightSQL + "," + goalDateSQL;
            db.insert("goal",
                    "_id, goal_current_weight, goal_date",stringInput);


            db.close();

            //move user to mainActivity
            Intent i = new Intent(SignUp.this, SignUpGoal.class);
            startActivity(i);



        }

        else {
            textViewErrorMessage.setText(errorMessage);
            textViewErrorMessage.setVisibility(View.VISIBLE);
        }

    }
}